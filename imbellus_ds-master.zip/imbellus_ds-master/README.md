
Please read [EDA + First Model RMarkdown](./eda.Rmd) notebook first.

the second and third model are shown in this [Jupyter notebook](./imbellus_explore.ipynb)
